﻿namespace LoginRestApi.Controllers
{
    public class Person
    {
        public String uid { get; set; }
        public String password { get; set; }
    }
}
